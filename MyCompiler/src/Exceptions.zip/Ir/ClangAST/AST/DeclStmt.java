package Ir.ClangAST.AST;

public class DeclStmt extends Stmt{


}
