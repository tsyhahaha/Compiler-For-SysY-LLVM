package Ir.ClangAST.AST;

public class Stmt {
}
