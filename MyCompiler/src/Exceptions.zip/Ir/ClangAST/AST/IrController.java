package Ir.ClangAST.AST;

import FrontEnd.ParserNode;

public class IrController {
    private ParserNode root;

    public IrController(ParserNode root) {
        this.root = root;
    }

    public void run() {

    }
}
