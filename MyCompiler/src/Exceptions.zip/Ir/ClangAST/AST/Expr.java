package Ir.ClangAST.AST;

import Exceptions.IrError;

public class Expr extends Stmt {

    public Object getValue() throws IrError {
        return null;
    }
}
