package Ir.ClangAST.AST;

public enum Op {
    add, minus, mult, div, mod,
    and, or, lt, le, ge, gt, eq, ne, not
}
