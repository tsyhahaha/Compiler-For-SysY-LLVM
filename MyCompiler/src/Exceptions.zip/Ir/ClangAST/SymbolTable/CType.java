package Ir.ClangAST.SymbolTable;

public enum CType {
    VOID,INT
}
