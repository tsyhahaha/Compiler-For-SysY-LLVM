package Ir.LLVMIR.IRInstr;

public interface LogicIR {
}
